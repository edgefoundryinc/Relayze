import '../styles/pricing.css'

function Pricing() {
  return (
    <div className="pricing-container">
      <div className="block-label">Pricing Component</div>
      {/* TODO: Add pricing tiers and plans */}
    </div>
  )
}

export default Pricing

