import Layout from '../layout'

function HomePage() {
  return <Layout />
}

export default HomePage

