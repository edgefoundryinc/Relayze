import ComingSoon from '../ComingSoon'

function SignupPage() {
  return (
    <ComingSoon 
      title="Sign Up"
      description="Create your free Posthook account and start testing webhooks in seconds. No credit card required."
    />
  )
}

export default SignupPage

