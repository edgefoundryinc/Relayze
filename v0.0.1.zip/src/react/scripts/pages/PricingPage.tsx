import ComingSoon from '../ComingSoon'

function PricingPage() {
  return (
    <ComingSoon 
      title="Pricing"
      description="Simple, transparent pricing for developers and teams. Start testing webhooks for free, scale as you grow."
    />
  )
}

export default PricingPage

